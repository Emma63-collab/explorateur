<?php 
 if (session_status() === PHP_SESSION_NONE) {
    session_start();
 }

    header("content-type: application/json");

    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(["success" => false, "message" => "Non connecté"]);
        exit;
    }