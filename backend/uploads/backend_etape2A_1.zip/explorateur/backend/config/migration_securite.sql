-- ============================================================
-- Migration sécurité — Étape 1
-- À exécuter dans phpMyAdmin ou via : mysql -u root explorateur < migration_securite.sql
-- ============================================================

-- 1. Ajouter mime_type dans la table files (nécessaire pour le nouvel upload.php)
ALTER TABLE files
  ADD COLUMN IF NOT EXISTS mime_type VARCHAR(100) NULL AFTER type,
  ADD COLUMN IF NOT EXISTS created_at DATETIME NULL AFTER user_id;

-- 2. Table trash — traçabilité de la corbeille en base de données
CREATE TABLE IF NOT EXISTS trash (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    original_name VARCHAR(255)  NOT NULL,
    original_path VARCHAR(1000) NOT NULL,
    trash_filename VARCHAR(255) NOT NULL COMMENT 'Nom sur disque dans /trash/ : timestamp_originalname',
    deleted_by  INT UNSIGNED NOT NULL,
    deleted_at  DATETIME     NOT NULL DEFAULT NOW(),
    restored    TINYINT(1)   NOT NULL DEFAULT 0,
    restored_at DATETIME     NULL,
    FOREIGN KEY (deleted_by) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_deleted_by (deleted_by),
    INDEX idx_trash_filename (trash_filename)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Table sessions — pour le "Remember me" fonctionnel
CREATE TABLE IF NOT EXISTS sessions (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NOT NULL,
    token      VARCHAR(128) NOT NULL UNIQUE COMMENT 'Token aléatoire sécurisé (bin2hex random_bytes)',
    expires_at DATETIME     NOT NULL,
    created_at DATETIME     NOT NULL DEFAULT NOW(),
    ip_address VARCHAR(45)  NULL,
    user_agent TEXT         NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Index manquants sur la table files pour les requêtes fréquentes
ALTER TABLE files
  ADD INDEX IF NOT EXISTS idx_name_path (name, path),
  ADD INDEX IF NOT EXISTS idx_user_id  (user_id);

-- 5. Index sur historique
ALTER TABLE historique
  ADD INDEX IF NOT EXISTS idx_user_id    (user_id),
  ADD INDEX IF NOT EXISTS idx_created_at (created_at);

-- 6. Index sur versions
ALTER TABLE versions
  ADD INDEX IF NOT EXISTS idx_file_id (file_id);
