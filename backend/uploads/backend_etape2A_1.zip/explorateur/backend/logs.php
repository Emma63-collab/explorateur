<?php
require_once __DIR__ . '/config/cors.php';

/* ==========================
   CORS
========================== */

/* ==========================
   AUTH
========================== */
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([]);
    exit;
}

if ($_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode([]);
    exit;
}

/* ==========================
   LECTURE LOG
========================== */
$logFile = __DIR__ . "/logs/actions.log";

if (!file_exists($logFile)) {
    echo json_encode([]);
    exit;
}

$lines = array_reverse(file($logFile, FILE_IGNORE_NEW_LINES));
$result = [];

foreach ($lines as $line) {
    preg_match(
        '/\[(.*?)\] user:(\d+) \| action:(.*?) \| target:(.*)/',
        $line,
        $matches
    );

    if ($matches) {
        $result[] = [
            "date"   => $matches[1],
            "user"   => $matches[2],
            "action" => $matches[3],
            "target" => $matches[4]
        ];
    }
}

echo json_encode($result);
