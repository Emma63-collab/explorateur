<?php
require_once __DIR__ . '/config/cors.php';
require_once __DIR__ . '/auth/auth.php';
require_once __DIR__ . '/config/database.php';

$data = json_decode(file_get_contents('php://input'), true);

$username = trim($data['username'] ?? '');
$password = trim($data['password'] ?? '');

if ($username === '' || $password === '') {
    echo json_encode(['success' => false, 'message' => 'Champs manquants']);
    exit;
}

if (strlen($username) < 3 || strlen($username) > 50) {
    echo json_encode(['success' => false, 'message' => 'Nom d\'utilisateur : 3 à 50 caractères']);
    exit;
}

if (strlen($password) < 8) {
    echo json_encode(['success' => false, 'message' => 'Mot de passe trop court (8 caractères minimum)']);
    exit;
}

// Vérifier si le nom existe déjà
$stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
$stmt->execute([$username]);

if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'message' => 'Ce nom d\'utilisateur est déjà pris']);
    exit;
}

$hashed  = password_hash($password, PASSWORD_DEFAULT);
$role_id = 2; // user par défaut

$stmt = $pdo->prepare("INSERT INTO users (username, password, role_id) VALUES (?, ?, ?)");

if ($stmt->execute([$username, $hashed, $role_id])) {
    echo json_encode(['success' => true, 'message' => 'Compte créé avec succès']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erreur lors de la création du compte']);
}
