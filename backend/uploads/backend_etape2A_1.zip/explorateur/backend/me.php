<?php
require_once __DIR__ . '/config/cors.php';
require_once __DIR__ . '/auth/auth.php';



if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "connected" => false]);
    exit;
}

$role = "user";
if (isset($_SESSION['role_id']) && $_SESSION['role_id'] == 1) {
    $role = "admin";
}

echo json_encode([
    "success" => true,
    "connected" => true,
    "user_id" => $_SESSION['user_id'],
    "role" => $role,
    "username" => $_SESSION['username'] ?? ''
]);
