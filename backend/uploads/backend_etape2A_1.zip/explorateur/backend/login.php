<?php
require_once __DIR__ . '/config/cors.php';
require_once __DIR__ . '/auth/auth.php';

$data = json_decode(file_get_contents('php://input'), true);

$username = trim($data['username'] ?? '');
$password = trim($data['password'] ?? '');

if ($username === '' || $password === '') {
    echo json_encode(['success' => false, 'message' => 'Nom d\'utilisateur ou mot de passe manquant']);
    exit;
}

$user = login($username, $password);

if (!$user) {
    // Message générique volontaire : ne pas préciser si c'est le login ou le mdp qui est faux
    echo json_encode(['success' => false, 'message' => 'Identifiants incorrects']);
    exit;
}

$role = ((int)$user['role_id'] === 1) ? 'admin' : 'user';

echo json_encode([
    'success'  => true,
    'message'  => 'Connexion réussie',
    'role'     => $role,
    'username' => $user['username'],
]);
