<?php
/*
 * Fonctions d'authentification.
 * display_errors désactivé : les erreurs vont dans le log serveur, pas dans la réponse JSON.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function isAdmin(): bool {
    return isset($_SESSION['role_id']) && (int)$_SESSION['role_id'] === 1;
}

function login(string $username, string $password): array|false {
    global $pdo;

    $stmt = $pdo->prepare("SELECT id, username, password, role_id FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['role_id']  = $user['role_id'];
        $_SESSION['username'] = $user['username'];
        return $user;
    }

    return false;
}

function logout(): void {
    session_unset();
    session_destroy();
}
