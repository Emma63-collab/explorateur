<?php
require_once __DIR__ . '/config/cors.php';


if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    exit("Non connecté");
}

$path = $_GET['path'] ?? '';

$baseDir = realpath(__DIR__ . '/uploads');
$filePath = realpath($baseDir . '/' . $path);

if (!$filePath || strpos($filePath, $baseDir) !== 0 || !is_file($filePath)) {
    http_response_code(404);
    exit("Fichier introuvable");
}

$mime = mime_content_type($filePath);

header("Content-Type: $mime");
header("Content-Disposition: inline; filename=\"" . basename($filePath) . "\"");
header("Content-Length: " . filesize($filePath));

readfile($filePath);
exit;
